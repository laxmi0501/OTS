from django.contrib import admin
from django.urls import path
from ExamEase.views import *

app_name = 'ExamEase'
urlpatterns = [
    path('home',home,name='home'),
    path('login',loginView,name='login'),
    path('new-candidate',candidateRegistrationForm, name='registrationForm'),
    path('store-candidate',signUp,name='signUp'),
    path('dashboard',dashboard,name='dashboard'),
    path('profile',profile, name='profile'),
    path('test-history',testHistory,name='testHistory'),
    path('test-of-the-day',testOfTheDay,name='TOTD'),
    path('testpaper',testpaper,name='testPaper'),
    path('calculate-result',calculateResult,name='calculateResult'),
    path('result',showResult,name='result'),
    path('logout',logOutView,name='logout')    
]
