from django.db import models

# models
# ----- candidate table ----- 
class Candidate(models.Model):
    username = models.CharField(primary_key=True, max_length=20)
    password= models.CharField(null=False, max_length=20)
    name= models.CharField(null=False,max_length=10)
    # lastname= models.CharField(null=False,max_length=20)
    email = models.EmailField()
    phone = models.IntegerField()
    # grade = models.IntegerField()
    DOB = models.CharField(max_length=10)
    test_attempted= models.IntegerField(default=0)
    points= models.FloatField(default=0.0)

#------- Table for saving result -------
class Result(models.Model):
    result_id= models.BigAutoField(primary_key=True,auto_created=True)
    username= models.ForeignKey(Candidate,on_delete= models.CASCADE)
    date= models.DateField(auto_now_add=True)
    time= models.TimeField(auto_now=True)
    attempt= models.IntegerField()
    right= models.IntegerField()
    wrong= models.IntegerField()
    points= models.FloatField()
      
# ------ Tables for different class questions -----
class class10(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class9(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class8(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class7(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class6(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class5(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class4(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class3(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class2(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

class class1(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)

# Model for test of the day 
class dailyTest(models.Model):
    qid = models.BigAutoField(primary_key=True,auto_created=True)
    ques = models.TextField()
    a = models.CharField(max_length=255)
    b = models.CharField(max_length=255)
    c = models.CharField(max_length=255)
    d = models.CharField(max_length=255)
    ans = models.CharField(max_length=2)


