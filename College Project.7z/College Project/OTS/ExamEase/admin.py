from django.contrib import admin
from ExamEase.models import *

# Register your models here.
admin.site.register(Candidate)
admin.site.register(class10)
admin.site.register(class9)
admin.site.register(class8)
admin.site.register(class7)
admin.site.register(class6)
admin.site.register(class5)
admin.site.register(class4)
admin.site.register(class3)
admin.site.register(class2)
admin.site.register(class1)
admin.site.register(dailyTest)
