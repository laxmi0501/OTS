from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse, HttpResponseRedirect
from ExamEase.models import *
from easygui import *  #Used to create popup during signUp.
import random
# Views

# ---- for rendering home page -----
def home(request): 
    template =loader.get_template('index.html')
    return HttpResponse(template.render())

# ---- for rendering login page -----
def loginView(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        candidate=Candidate.objects.filter(username=username,password=password)
        if(len(candidate)==0):
            loginError="Invalid Username or Password"
            res=render(request,'login.html',{'loginError':loginError})
        else:
            # login successful
            request.session['username']=candidate[0].username
            request.session['name']=candidate[0].name
            res= HttpResponseRedirect('dashboard')

    else:
        res=render(request, 'login.html')
    return res


# ---- candiate Registration Form for signUp ---- 
def candidateRegistrationForm(request):
    res = render(request, 'signup.html')
    return res

# ---- signUp status -----
def signUp(request):
    if request.method=='POST': #UPPER CASE
        Username= request.POST['username']
        #check if the user already exists
        if(len(Candidate.objects.filter(username=Username))):
            userStatus=1
        else:
            candidate=Candidate()
            candidate.username=Username
            candidate.password=request.POST['pass']
            candidate.name=request.POST['name']
            candidate.DOB=request.POST['birthday']
            candidate.email=request.POST['email']
            candidate.phone=request.POST['phone']
            candidate.save() # candidate registered in the table
            userStatus=2
    else:
         userStatus=3 #Request method is not POST
    if userStatus ==1:
        msgbox(msg='Username already exists, please enter a different username',title='User Status',ok_button='OK')
        res=render(request, 'signup.html')
    elif userStatus==2:
        msgbox(msg='User has been created successfully! \nPlease LOGIN to continue.',title='User Status',ok_button='Login')
        res=render(request, 'login.html')
    elif userStatus==3:
        msgbox(msg='Unappropriate Request.\nPlease SignUp again to continue.',title='User Status',ok_button='SignUp')
        res=render(request, 'signup.html')
        
    # context={'userStatus':userStatus}
    return res

# ---- candidate home page -----
def dashboard(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')
    else:
        res = render(request, 'dashboard.html')
    return res

# ---- candiate Profile ----
def profile(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')
    res= render(request,'profile.html')
    return res

# ---- daily test ----
def testOfTheDay(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')

    ques_daily=list(dailyTest.objects.all())
    random.shuffle(ques_daily)
    ques_list=ques_daily[:10]
    context = {'questions': ques_list}
    res=render(request,'test_paper.html',context)
    return res



# ---- For taking test -----
def testpaper(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')

    n = int(request.GET['n'])
    m = int(request.GET['m'])

    # fetching Questions from database table

    ques_10=list(class10.objects.all())
    ques_9=list(class9.objects.all())
    ques_8=list(class8.objects.all())
    ques_7=list(class7.objects.all())
    ques_6=list(class6.objects.all())
    ques_5=list(class5.objects.all())
    ques_4=list(class4.objects.all())
    ques_3=list(class3.objects.all())
    ques_2=list(class2.objects.all())
    ques_1=list(class1.objects.all())
    if m==10:
        ques_pool=ques_10
    elif m==9:
        ques_pool=ques_9
    elif m==8:
        ques_pool=ques_8
    elif m==7:
        ques_pool=ques_7
    elif m==6:
        ques_pool=ques_6
    elif m==5:
        ques_pool=ques_5
    elif m==4:
        ques_pool=ques_4
    elif m==3:
        ques_pool=ques_3
    elif m==2:
        ques_pool=ques_2
    elif m==1:
        ques_pool=ques_1

    random.shuffle(ques_pool)
    ques_list=ques_pool[:n]
    context = {'questions': ques_list}
    res=render(request,'test_paper.html',context)
    return res

# ---- for calculating result ----
def calculateResult(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')
    total_attempt=0
    total_right=0
    total_wrong=0
    qid_list=[]
    # q = Question1()
    for  k in request.POST: #keys of post dictionary recieved in variable k
        if k.startswith('qno'):
            qid_list.append(int(request.POST[k])) #append the is of attempted questions in list
    for n in qid_list:
        question = dailyTest.objects.get(qid=n) #get gives only one result unlike filter
        try:
            if question.ans==request.POST['q'+str(n)]: #matching the ans with user's ans
                total_right+=1
            else:
                total_wrong+=1
            total_attempt+=1
        except:
            pass
    points=(total_right-total_wrong)/len(qid_list)*10
    #store result in Result table
    result = Result()
    result.username=Candidate.objects.get(username=request.session['username']) #we have to assign object from candidate table because username is a foreign key here
    result.attempt=total_attempt
    result.right=total_right
    result.wrong=total_wrong
    result.points=points
    result.save()
    #update Candidate table
    candidate=Candidate.objects.get(username=request.session['username'])
    candidate.test_attempted+=1
    candidate.points=(candidate.points*(candidate.test_attempted-1)+points)/candidate.test_attempted
    candidate.save()
    return HttpResponseRedirect('result')
    

# ---to see result ----
def showResult(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')
    
     # fetch latest result from Result table
    result=Result.objects.filter(result_id=Result.objects.latest('result_id').result_id,username_id=request.session['username'])
    context={'result':result}
    res = render(request,'result.html',context)
    return res

# --- result history -----
def testHistory(request):
    if 'name' not in request.session.keys():
        res = HttpResponseRedirect('login')

    candidate=Candidate.objects.filter(username=request.session['username'])
    results=Result.objects.filter(username_id=candidate[0].username) # filter gives query set always and query set collection of objefcts
    context ={'candidate':candidate[0], 'results':results}
    res = render(request,'resulthistory.html',context)
    return res


# ---- log Out ----
def logOutView(request):
    if 'name' in request.session.keys():
        del request.session['username']
        del request.session['name']
    return HttpResponseRedirect('login')

